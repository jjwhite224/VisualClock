export default { 
    chokidarWatchOptions: {
     usePolling: true
   }
 }